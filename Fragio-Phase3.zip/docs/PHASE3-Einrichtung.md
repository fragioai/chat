# Fragio – Einrichtung Phase 3 (nur mit dem iPhone)

Alles in dieser Anleitung läuft im Safari-Browser. Du brauchst keinen Computer, kein Terminal und keine Installation.

## 0. Was du nach dieser Anleitung hast – und was nicht

**Funktioniert:** Registrierung, Anmeldung (E-Mail und Google), E-Mail-Bestätigung, Passwort-Reset, geschützter Kontobereich mit Guthaben und Buchungsliste, Kontolöschung, helles und dunkles Design.

**Funktioniert noch nicht:** Chat, KI-Modelle, Dateien, Aufladen, Zahlungen, Admin-Bereich. Das kommt in den Phasen 4 bis 8. Die Seite sagt das auch offen.

**Bitte beachte:** Ich konnte den Code hier nicht in einer echten Supabase- oder GitHub-Umgebung ausführen. Er ist sorgfältig geschrieben, aber **ungetestet im Live-Betrieb**. Deshalb gibt es unten eine Testliste und eine Fehlerbehebung. Sag mir bei jedem Fehler genau, was auf dem Bildschirm steht, dann korrigiere ich es.

## 1. Kosten

| Bestandteil | Kosten |
|---|---|
| GitHub (öffentliches Repository, GitHub Pages, GitHub Actions) | kostenlos |
| Supabase Free-Tarif | kostenlos, aber mit Grenzen (siehe unten) |
| Google Cloud (nur für „Mit Google fortfahren“) | kostenlos für diese Nutzung |
| Domain | optional, später |

Grenzen des kostenlosen Supabase-Tarifs (Stand meiner Recherche am 03.11.2026, bitte bei Supabase gegenprüfen):
- Das Projekt wird nach **7 Tagen ohne Aktivität pausiert** und muss dann im Dashboard von Hand wieder gestartet werden. Das ist für eine Seite, die nur Familie nutzt, ein reales Risiko.
- Edge Functions haben auf dem Free-Tarif ein Zeitlimit von etwa 150 Sekunden und 2 Sekunden CPU-Zeit pro Anfrage. Das betrifft vor allem lange KI-Antworten in Phase 4.
- Laut Supabase-Doku sind ausgehende Verbindungen von Edge Functions zu den Ports 25 und 587 gesperrt. Das ist wichtig für den späteren E-Mail-Versand per Gmail (Phase 7), dort plane ich Port 465 ein.
- Der eingebaute E-Mail-Versand von Supabase ist stark begrenzt. Bei vielen Registrierungen kommen Bestätigungs-Mails verzögert oder gar nicht an. Ich richte in Phase 7 einen eigenen Versand über Gmail ein.

## 2. GitHub-Konto und Repository

1. Öffne **github.com/signup** und erstelle ein Konto mit dem Benutzernamen **fragio**. Ist der Name vergeben, wähle einen anderen. Deine Adresse ist dann `https://DEINNAME.github.io/chat/`. Merke dir den Namen, er wird unten mehrfach gebraucht.
2. Bestätige die E-Mail-Adresse.
3. Tippe oben rechts auf **+** → **New repository**.
4. **Repository name: `chat`** (genau so, denn daraus entsteht der Pfad `/chat/`).
5. Sichtbarkeit **Public**. Hinweis: Alle Dateien sind dann öffentlich lesbar. Deshalb darf dort nie ein geheimer Schlüssel stehen.
6. Tippe **Create repository**.

## 3. Zwei Workflow-Dateien von Hand anlegen

GitHub erlaubt es nicht, dass automatische Abläufe sich selbst ändern. Diese zwei Dateien legst du einmal von Hand an. Den Text zum Kopieren findest du am Ende dieser Anleitung (Anhang A und B).

**3a. `unpack.yml`**
1. Im Repository: **Add file** → **Create new file**.
2. Im Namensfeld tippe genau: `.github/workflows/unpack.yml` (die Schrägstriche legen die Ordner an).
3. Füge den Text aus **Anhang A** ein (Text im Codeblock lange antippen → Alles auswählen → Kopieren, dann im GitHub-Feld einfügen).
4. **Commit changes…** → **Commit changes**.

**3b. `deploy-pages.yml`**: gleiches Vorgehen mit dem Namen `.github/workflows/deploy-pages.yml` und dem Text aus **Anhang B**.

## 4. Projektdateien hochladen

1. Lade die Datei **Fragio-Phase3.zip** aus dem Chat herunter. Sie liegt in der Dateien-App.
2. Im Repository: **Add file** → **Upload files** → **choose your files** → die ZIP-Datei auswählen.
3. Warte, bis der Upload fertig ist, dann **Commit changes**.
4. Tippe oben auf **Actions**. Falls GitHub fragt, ob Workflows aktiviert werden sollen, bestätige.
5. Links **Dateien entpacken** → **Run workflow** → grüner Knopf **Run workflow**.
6. Nach etwa einer Minute sollte ein grüner Haken erscheinen. Im Reiter **Code** siehst du jetzt die Ordner `src`, `supabase`, `docs` und die Dateien `package.json` und andere.

Bei einem roten Haken: Tippe auf den Lauf, dann auf den Schritt mit dem roten Kreuz und schicke mir die Fehlermeldung.

## 5. Supabase-Projekt anlegen

1. Öffne **supabase.com** → **Start your project** → mit GitHub oder E-Mail anmelden.
2. Lege eine Organisation an (Name beliebig, Typ „Personal“, Plan **Free**).
3. **New project**: Name `fragio`, ein starkes Datenbank-Passwort (im Passwortmanager speichern, wir brauchen es nicht in der App), Region **Central EU (Frankfurt)** oder die nächste EU-Region, Plan **Free**.
4. Warte, bis das Projekt bereit ist (ein paar Minuten).

## 6. Datenbank einrichten (SQL)

1. Im Supabase-Projekt links **SQL Editor** (am iPhone eventuell über das Menü oben links) → **New query**.
2. Öffne in deinem GitHub-Repository die Datei `supabase/migrations/0001_grundsystem.sql`, tippe oben rechts auf **Raw**, markiere alles, kopiere es.
3. Füge es im SQL Editor ein und tippe **Run**. Erwartet: „Success. No rows returned“.
4. Neue Abfrage: Das Gleiche mit `0002_rls.sql`.
5. Neue Abfrage: Das Gleiche mit `supabase/tests/phase3_checks.sql`. **Erwartet: In der Spalte „ok“ steht überall `true`.** Wenn irgendwo `false` steht, mach einen Screenshot und schick ihn mir, bevor du weitermachst.

Die Migrationen kannst du bei Bedarf noch einmal ausführen, sie überschreiben keine Daten.

## 7. Anmelde-Einstellungen in Supabase

Die Menünamen ändern sich bei Supabase gelegentlich. Wenn du einen Eintrag nicht findest, suche in der Seitenleiste nach dem Begriff.

1. **Authentication** → **URL Configuration**:
   - **Site URL:** `https://fragio.github.io/chat/` (mit deinem GitHub-Namen).
   - **Redirect URLs:** `https://fragio.github.io/chat/**` hinzufügen.
2. **Authentication** → **Sign In / Providers** → **Email**: aktiviert lassen, **Confirm email** eingeschaltet lassen, falls es eine Einstellung für die Mindestlänge des Passworts gibt, auf **8** stellen.
3. Empfehlung: Bei offener Registrierung unter **Authentication → Attack Protection** einen Captcha-Schutz aktivieren, falls verfügbar. Das ist optional, schützt aber vor Massenanmeldungen. Ich baue die Unterstützung in einer späteren Phase ein, wenn du es möchtest.

## 8. „Mit Google fortfahren“ einrichten

1. Öffne **console.cloud.google.com** und melde dich mit deinem Google-Konto an. Lege ein Projekt `Fragio` an.
2. Menü **APIs & Services** (oder **Google Auth Platform**) → **OAuth consent screen**: Typ **External**, App-Name `Fragio`, deine E-Mail als Support-Adresse, speichern. Verwendet werden nur die Standard-Bereiche `email`, `profile`, `openid`.
3. Wenn die App auf „Testing“ steht, können sich nur eingetragene Testnutzer anmelden. Für Familie und Freunde trage entweder jeden als Testnutzer ein oder setze den Status auf „In production“ (für diese Standard-Bereiche ist normalerweise keine Prüfung durch Google nötig, das solltest du in der Google-Oberfläche kurz selbst gegenlesen).
4. **Credentials** → **Create credentials** → **OAuth client ID** → Typ **Web application**.
5. Bei **Authorized redirect URIs** trage ein: `https://DEINE-PROJEKT-ID.supabase.co/auth/v1/callback`. Die Projekt-ID findest du in Supabase unter **Project Settings** → **General** (Reference ID).
6. Speichern. Google zeigt **Client ID** und **Client Secret**.
7. Zurück in Supabase: **Authentication** → **Sign In / Providers** → **Google** → einschalten, Client ID und Client Secret eintragen, **Save**.

Das Client Secret ist geheim und gehört nur in dieses Supabase-Feld, nicht ins GitHub-Repository.

## 9. Öffentliche Einstellungen in GitHub eintragen

1. In Supabase: **Project Settings** → **API** (oder **API Keys**). Notiere die **Project URL** (`https://….supabase.co`) und den **öffentlichen Schlüssel**: den **publishable key** (früher „anon key“ genannt). **Niemals** den `secret`- oder `service_role`-Schlüssel verwenden. Die Seite blockiert solche Schlüssel zwar, aber vermeide es von vornherein.
2. In GitHub im Repository: **Settings** → **Secrets and variables** → **Actions** → Reiter **Variables** → **New repository variable**:
   - Name `VITE_SUPABASE_URL`, Wert: deine Project URL.
   - Name `VITE_SUPABASE_ANON_KEY`, Wert: der publishable key.
   Wichtig: Reiter **Variables**, nicht „Secrets“. Diese Werte sind öffentlich gedacht und werden in die Seite eingebaut.

## 10. Veröffentlichung einschalten

1. Im Repository: **Settings** → **Pages** → bei **Source** **GitHub Actions** wählen.
2. **Actions** → **Website veröffentlichen** → **Run workflow**.
3. Nach ein bis drei Minuten grüner Haken. Deine Seite: `https://fragio.github.io/chat/`.

## 11. Edge Function für die Kontolöschung einrichten

1. In Supabase: **Edge Functions** → **Deploy a new function** → **Via Editor**.
2. Name: `delete-account`. Ersetze den Beispielcode durch den Inhalt von `supabase/functions/delete-account/index.ts` aus deinem Repository (Raw-Ansicht kopieren).
3. **Deploy**. Die Einstellung „Verify JWT“ soll eingeschaltet bleiben.
4. Optional, aber empfohlen: **Edge Functions** → **Secrets** → Name `ALLOWED_ORIGIN`, Wert `https://fragio.github.io` (mit deinem GitHub-Namen, ohne `/chat/`). Ohne diesen Wert gilt `https://fragio.github.io` als Standard.

## 12. Testliste

Bitte geh das einmal durch und sag mir, bei welchem Punkt es hakt:

1. Seite öffnen: Es erscheint die Anmeldung (keine Fehlermeldung „Einrichtung unvollständig“).
2. Mit einer zweiten E-Mail-Adresse **Konto erstellen**: Hinweis auf die Bestätigungs-Mail erscheint. Mail öffnen, Link tippen, du bist angemeldet.
3. **Abmelden** und wieder **Anmelden**.
4. **Passwort vergessen?** → Mail kommt → Link → neues Passwort setzen → du bist angemeldet.
5. **Mit Google fortfahren** funktioniert.
6. Reiter **Konto**: Name, E-Mail, Guthaben 0,00 €, „Noch keine Buchungen“.
7. Seite neu laden (Safari aktualisieren) auf dem Reiter Konto: Die Seite bleibt erreichbar.
8. Hell/Dunkel umschalten.
9. Mit einem **Testkonto** unter **Konto löschen** das Löschen ausprobieren. Danach funktioniert die Anmeldung mit dem Konto nicht mehr.
10. Der SQL-Selbsttest aus Schritt 6 zeigt weiter nur `true`.

## 13. Fehlerbehebung

| Problem | Ursache und Lösung |
|---|---|
| „Einrichtung unvollständig“ | Variablen fehlen oder falsch geschrieben (Schritt 9). Nach dem Korrigieren **Website veröffentlichen** erneut starten. |
| Weiße Seite oder 404 | Repository heißt nicht genau `chat`, oder Pages-Quelle nicht auf „GitHub Actions“ (Schritt 10). |
| Workflow „Website veröffentlichen“ rot | Fehlermeldung aus dem roten Schritt an mich schicken. |
| Bestätigungs-Mail kommt nicht | Spam-Ordner prüfen, einige Minuten warten. Der eingebaute Versand ist stark begrenzt (siehe Abschnitt 1). |
| Nach Klick auf den Mail-Link Fehlerseite | Redirect-URL in Schritt 7 prüfen (muss mit `/**` enden). |
| Google meldet „redirect_uri_mismatch“ | Die Redirect-URI in der Google-Konsole (Schritt 8.5) stimmt nicht exakt. |
| Kontolöschung schlägt fehl | Function nicht bereitgestellt (Schritt 11), oder die Meldung auf der Seite nennt den Grund (Guthaben bestätigen, offene Reservierungen). |
| Supabase-Projekt „paused“ | Im Supabase-Dashboard auf **Restore project** tippen. |

## 14. Spätere Änderungen und Aktualisierungen

Neue Versionen bekommst du als neue ZIP-Datei. Dann: ZIP in den Hauptordner des Repositories hochladen, **Dateien entpacken** ausführen. Danach startet die Veröffentlichung automatisch. Falls nicht, **Website veröffentlichen** von Hand starten. Dateien, die in einer neuen Version wegfallen, löschst du bei Bedarf von Hand im Repository (Datei öffnen → Papierkorb-Symbol).

## 15. Schlüssel und Sicherheit

- Im Repository und in GitHub-Variablen steht **nur** die Project URL und der öffentliche Schlüssel. Beides ist für den Browser vorgesehen.
- Geheime Schlüssel (Service Role, Anthropic, Google, Stripe, Gmail) kommen später ausschließlich in **Supabase → Edge Functions → Secrets**.
- Schlüssel erneuern (rotieren) wirst du bei Bedarf unter **Project Settings → API** tun. Danach den neuen öffentlichen Schlüssel in der GitHub-Variable ersetzen und die Veröffentlichung neu starten. Die genaue Anleitung für alle Schlüssel kommt in der Gesamtanleitung (Phase 10).

## 16. Bekannte Grenzen von Phase 3

- Es gibt noch keine Datenschutzerklärung, kein Impressum und keine Nutzungsbedingungen auf der Seite. Die schreibe ich in Phase 9. Bis dahin gib den Link nur an Menschen, die du kennst.
- Für den Admin-Bereich ist nur die Datenbank-Grundlage vorhanden, noch keine Oberfläche.
- Der Code ist hier nicht live getestet (siehe Abschnitt 0).

## Anhang A: unpack.yml

```yaml
name: Dateien entpacken

on:
  workflow_dispatch:

permissions:
  contents: write

jobs:
  unpack:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: ZIP-Datei im Hauptordner entpacken
        run: |
          set -e
          ZIP=$(ls -1 *.zip 2>/dev/null | head -n 1 || true)
          if [ -z "$ZIP" ]; then
            echo "FEHLER: Keine ZIP-Datei im Hauptordner des Repositories gefunden."
            exit 1
          fi
          echo "Entpacke $ZIP"
          unzip -o "$ZIP" -x ".github/*" "__MACOSX/*"
          rm "$ZIP"
          git config user.name "github-actions"
          git config user.email "github-actions@users.noreply.github.com"
          git add -A
          git commit -m "Dateien aus ZIP entpackt" || echo "Keine Änderungen"
          git push
```

## Anhang B: deploy-pages.yml

```yaml
name: Website veröffentlichen

on:
  push:
    branches: [main]
  workflow_dispatch:
  workflow_run:
    workflows: ["Dateien entpacken"]
    types: [completed]

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: pages
  cancel-in-progress: false

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - name: Pakete installieren
        run: npm install --no-audit --no-fund
      - name: Website bauen
        env:
          VITE_SUPABASE_URL: ${{ vars.VITE_SUPABASE_URL }}
          VITE_SUPABASE_ANON_KEY: ${{ vars.VITE_SUPABASE_ANON_KEY }}
        run: npm run build
      - uses: actions/configure-pages@v5
      - uses: actions/upload-pages-artifact@v3
        with:
          path: dist

  deploy:
    needs: build
    runs-on: ubuntu-latest
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    steps:
      - id: deployment
        uses: actions/deploy-pages@v4
```
